"""VMware vSphere (vCenter) inventory collection provider."""
from .provider import VMwareVSphereProvider

__all__ = ['VMwareVSphereProvider']
