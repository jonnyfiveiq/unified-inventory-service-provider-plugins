"""Amazon Web Services (EC2) inventory collection provider."""

from .provider import AWSCloudProvider

__all__ = ['AWSCloudProvider']
